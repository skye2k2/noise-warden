# Recommended Hardware BOM (v2)

- Raspberry Pi 4B (4GB) or Pi 5
- Official PSU
- 64GB A2 microSD or SSD boot
- USB audio interface (class-compliant)
- Directional shotgun mic (RØDE VideoMic GO II recommended)
- Wind protection / deadcat
- Shielded cable
- Optional secondary mic (for dual-mic testing)
- Optional loopback/reference capture path (for adaptive subtraction testing)
- TPA3116-based amp
- 12V PSU
- 1-channel opto-isolated relay
- Speaker(s)
- Handheld SPL meter for calibration
