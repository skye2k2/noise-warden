# Hardware Shopping List

- Raspberry Pi 4B (4GB+) or Pi 5
- Official PSU
- 32GB+ microSD or USB SSD
- USB audio interface (Linux-friendly)
- Directional microphone (shotgun / supercardioid)
- Windscreen / deadcat
- Optional second directional mic
- Optional reference loopback source later
- 5V opto-isolated relay module
- External amplifier + speakers
- Outdoor-safe cable management / enclosure
